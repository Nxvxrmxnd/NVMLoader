﻿namespace UntStudio.Loader.API.Activators;

public interface IPluginActivator : INativeActivator
{
}
