﻿namespace UntStudio.Loader.API.Activators;

public interface IRocketModPluginActivator : IPluginActivator
{
}
