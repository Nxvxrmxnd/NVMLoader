﻿namespace UntStudio.Loader.API.Activators;

public interface IOpenModPluginActivator : IPluginActivator
{
}
