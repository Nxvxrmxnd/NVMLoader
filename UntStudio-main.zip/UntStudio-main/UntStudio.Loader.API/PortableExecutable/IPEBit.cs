﻿namespace UntStudio.Loader.API.PortableExecutable
{
    public interface IPEBit
    {
        byte[] Unbit(byte[] bytes);
    }
}
