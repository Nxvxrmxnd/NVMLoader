﻿namespace UntStudio.Loader.API;

public enum PluginFramework
{
    RocketMod,
    OpenMod
}
