﻿namespace UntStudio.Server.Knowns;

public static class KnownHttpClientNames
{
	public const string AdminsAPI = nameof(AdminsAPI);
}
