﻿namespace UntStudio.Server.Knowns;

public static class KnownPluginKeyLenghts
{
    public const int Lenght = 19;
}
