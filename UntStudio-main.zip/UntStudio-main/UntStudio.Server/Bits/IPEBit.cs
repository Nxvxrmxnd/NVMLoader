﻿namespace UntStudio.Server.Bits;

public interface IPEBit
{
    byte[] Bit(byte[] bytes);
}
