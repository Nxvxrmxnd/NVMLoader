﻿namespace UntStudio.Loader.Activators;

internal static class KnownInitialPluginFrameworkTypes
{
    internal const string RocketModInterface = "IRocketPlugin";
    internal const string OpenModInterface = "IOpenModPlugin";
}
